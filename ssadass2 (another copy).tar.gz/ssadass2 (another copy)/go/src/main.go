package main

import (
	"fmt"
	"io/ioutil"
	"time"

	"github.com/dgrijalva/jwt-go"
	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/sqlite"
)

var db *gorm.DB
var err error
var VerifyKey, SignKey []byte

const (
	privateKeyPath = "../../app.rsa"
	publicKeyPath  = "../../app.rsa.pub"
)

type Questions struct {
	Question             string  `json:"question"`
	Type                 string  `json:"type"`
	OptionA              string  `json:"optionA"`
	OptionB              string  `json:"optionB"`
	OptionC              string  `json:"optionC"`
	OptionD              string  `json:"optionD"`
	CorrectA             bool    `json:"correcta"`
	CorrectB             bool    `json:"correctb"`
	CorrectC             bool    `json:"correctc"`
	CorrectD             bool    `json:"correctd"`
	QuizName             string  `json:"quiz"`
	ScoreIDsForQuestions []Score `json:"scoreidsforquestions" gorm:"foreignkey:ScoreIDs"`
}
type Quizzes struct {
	Name               string      `json:"name" gorm:"primary_key"`
	Genre              string      `json:"genre"`
	Questions          []Questions `json:"questions" gorm:"foreignkey:QuizName"`
	MarksForCorrect    string      `json:"mfc"`
	MarksForIncorrect  string      `json:"mfi"`
	MarksForUnanswered string      `json:"mfu"`
}
type User struct {
	Username string `json:"username" gorm:"primary_key"`
	Password string `json:"password"`
	//ScoreIDsForUser []Score `json:"scoreidsforuser" gorm:"foreignkey:ScoreIDs"`
}

type Score struct {
	ID int `json:"id" gorm:"primary_key"`
	//User       string `json:"user"`
	Quiz       string `json:"quizPlayed"`
	Correct    int    `json:"correct"`
	Incorrect  int    `json:"incorrect"`
	Unanswered int    `json:"unanswered"`
	Points     int    `json:"points"`
}

type Token struct {
	Token string `json:"token"`
}

func initKeys() {
	var err error
	SignKey, err = ioutil.ReadFile(privateKeyPath)
	if err != nil {
		fmt.Println("Error reading private key")
		return
	}
	VerifyKey, err = ioutil.ReadFile(publicKeyPath)
	if err != nil {
		fmt.Println("Error reading public key")
		return
	}
}

func main() {
	db, err = gorm.Open("sqlite3", "./quizDataBase.db")
	if err != nil {
		fmt.Println(err)
	}
	defer db.Close()

	initKeys()

	db.AutoMigrate(&User{})
	db.AutoMigrate(&Questions{})
	db.AutoMigrate(&Quizzes{})

	router := gin.Default()
	router.GET("/users/:username", getUser)
	router.POST("/register", doReg)
	router.POST("/login", doLogin)
	router.POST("/createQuiz", doCreateQuiz)
	router.GET("/quizzes/:name", getQuiz)
	router.POST("/createQuestion", doCreateQuestion)
	router.GET("/getQuestions/:name", getQuestions)
	router.GET("/indexer", indexQuizzes)
	router.POST("/createScore", doCreateScore)
	router.Use((cors.Default()))
	router.Run(":8080")
}

func doLogin(c *gin.Context) {
	var user User
	var query1 User
	c.BindJSON(&user)
	c.Header("access-control-allow-origin", "*")
	if err := db.Where("username=?", user.Username).First(&query1).Error; err != nil {
		c.AbortWithStatus(404)
	} else {
		if query1.Password != user.Password {
			c.AbortWithStatus(404)
		} else {
			signer := jwt.New(jwt.GetSigningMethod("RS256"))

			claims := make(jwt.MapClaims)
			claims["username"] = user.Username
			claims["password"] = user.Password
			claims["exp"] = time.Now().Add(time.Minute * 120).Unix()
			claims["iss"] = "http://localhost:3000/"

			signer.Claims = claims

			fmt.Println(string(SignKey))
			key, _ := jwt.ParseRSAPrivateKeyFromPEM(SignKey)
			tokenString, err := signer.SignedString(key)
			if err != nil {
				fmt.Println(err)
				c.AbortWithStatus(500)
			}

			response := Token{tokenString}
			c.JSON(200, response)
		}
	}
}

func doCreateScore(c *gin.Context) {
	var score Score
	c.BindJSON(&score)
	c.Header("access-control-allow-origin", "*")
	db.Create(&score)
	c.JSON(200, score)
}

func getQuestions(c *gin.Context) {
	var questions []Questions
	var quiz Quizzes
	name := c.Params.ByName("name")
	c.Header("access-control-allow-origin", "*")
	db.Where("name=?", name).First(&quiz)
	fmt.Println(quiz)
	db.Model(&quiz).Related(&questions, "Questions")
	fmt.Println("herr", questions)
	c.JSON(200, questions)
}

func indexQuizzes(c *gin.Context) {
	var quizzes []Quizzes
	c.Header("access-control-allow-origin", "*")
	if err := db.Find(&quizzes).Error; err != nil {
		fmt.Println(err)
		c.AbortWithStatus(404)
	} else {
		fmt.Println(quizzes)
		c.JSON(200, quizzes)
	}
}

func doCreateQuestion(c *gin.Context) {
	var question Questions
	var quiz Quizzes
	c.BindJSON(&question)
	count := 0
	if question.CorrectA == false {
		count++
	}
	if question.CorrectB == false {
		count++
	}
	if question.CorrectC == false {
		count++
	}
	if question.CorrectD == false {
		count++
	}
	c.Header("access-control-allow-origin", "*")
	if question.Question == "" || count == 4 {
		c.AbortWithStatus(404)
	} else {
		db.Where("name=?", question.QuizName).First(&quiz)
		db.Create(&question)
		c.JSON(200, question)
	}
}

func doCreateQuiz(c *gin.Context) {
	var quiz Quizzes
	c.BindJSON(&quiz)
	c.Header("access-control-allow-origin", "*")
	if quiz.Name == "" || quiz.Genre == "" {
		c.AbortWithStatus(404)
	} else {
		db.Create(&quiz)
		c.JSON(200, quiz)
	}
}

func getQuiz(c *gin.Context) {
	name := c.Params.ByName("name")
	var quiz Quizzes
	c.Header("access-control-allow-origin", "*")
	if err := db.Where("name = ?", name).First(&quiz).Error; err != nil {
		c.AbortWithStatus(404)
	} else {
		c.JSON(200, quiz)
	}
}

func getUser(c *gin.Context) {
	username := c.Params.ByName("username")
	var user User
	c.Header("access-control-allow-origin", "*")
	if err := db.Where("username = ?", username).First(&user).Error; err != nil {
		c.AbortWithStatus(404)
	} else {
		c.JSON(200, user)
	}
}

func doReg(c *gin.Context) {
	var user User
	c.BindJSON(&user)
	c.Header("access-control-allow-origin", "*")
	if user.Username == "" || user.Password == "" {
		c.AbortWithStatus(404)
	} else {
		db.Create(&user)
		c.JSON(200, user)
	}
}
