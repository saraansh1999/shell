import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

class ListQuizzes extends Component {
  constructor() {
    super();
    this.state = {
      data: []
    };
    this.lister();
  }
  lister = () => {
    const request = new Request("http://127.0.0.1:8080/indexer");
    fetch(request).then(response => {
      response.json().then(data => {
        this.setState({ data });
      });
    });
  };
  render() {
    return (
      <React.Fragment>
        List of Quizzes:
        <br />
        <ul type="1">
          {this.state.data !== undefined
            ? this.state.data.map(function(value, key) {
                return (
                  <li>
                    <Link to={"/attemptQuiz/" + value.name}>{value.name}</Link>
                    <br />
                  </li>
                );
              })
            : function() {
                return;
              }}
        </ul>
      </React.Fragment>
    );
  }
}

export default ListQuizzes;
