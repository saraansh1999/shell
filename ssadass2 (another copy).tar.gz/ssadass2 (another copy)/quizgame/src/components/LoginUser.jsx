import React, { Component } from "react";
import Cookies from "universal-cookie";

class Login extends Component {
  state = {
    username: "",
    password: ""
  };

  handleUsernameChange = e => {
    const username = e.target.value;
    this.setState({ username });
  };

  handlePasswordChange = e => {
    const password = e.target.value;
    this.setState({ password });
  };

  handleSubmit = e => {
    e.preventDefault();
    var loginData = {
      username: this.state.username,
      password: this.state.password
    };
    fetch("http://127.0.0.1:8080/login", {
      method: "POST",
      body: JSON.stringify(loginData)
    }).then(response => {
      if (response.status === 404) {
        document.getElementById("loginMessage").textContent =
          "Incorrect Username or Password";
      } else if (response.status === 200) {
        document.getElementById("loginMessage").textContent =
          "Login Successful!";
        response.json().then(data => {
          const cookies = new Cookies();
          cookies.set("token", data.token, {
            path: "/",
            httpOnly: true,
            secure: true
          });
          console.log(cookies.get("token"));
        });
        // window.location.href = "/register";
      } else if (response.status === 500) {
        document.getElementById("loginMessage").textContent =
          "Internal Server Error";
      }
    });
  };

  render() {
    return (
      <React.Fragment>
        <br />
        <br />
        <br />
        <form onSubmit={e => this.handleSubmit(e)}>
          Username:{" "}
          <input
            type="text"
            name="username"
            value={this.state.username}
            onChange={e => this.handleUsernameChange(e)}
          />
          <br />
          Password:{" "}
          <input
            type="password"
            name="password"
            value={this.state.password}
            onChange={e => this.handlePasswordChange(e)}
          />
          <br />
          <button type="submit">Login</button>
        </form>
        <br />
        <div id="loginMessage"> </div>
      </React.Fragment>
    );
  }
}

export default Login;
