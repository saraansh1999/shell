import React, { Component } from "react";

class Logout extends Component {
  state = {};

  onLoad = () => {
    console.log("onload");
    fetch("http://127.0.0.1:8080/logout", {
      method: "GET",
      body: ""
    });
  };

  render() {
    return <div onLoad={() => this.onLoad()} />;
  }
}

export default Logout;
