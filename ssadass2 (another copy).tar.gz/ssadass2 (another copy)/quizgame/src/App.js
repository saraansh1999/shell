import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import Register from "./components/RegisterUser";
import Login from "./components/LoginUser";
import CreateQuiz from "./components/CreateQuiz";
import CreateQuestion from "./components/CreateQuestion";
import ListQuizzes from "./components/ListQuizzes";
import AttemptQuiz from "./components/AttemptQuiz";
import "./App.css";

class App extends Component {
  /* onLogoutHandler = () => {
    fetch("http://127.0.0.1:8080/logout", {
      method: "GET"
    }).then(response => {
      window.location.href = "/login";
    });
  };*/

  render() {
    return (
      <div>
        <Router>
          <div>
            <nav class="navbar navbar-light bg-light">
              QUIZGAME!
              <form class="form-inline">
                {/* <Link to={"/logout"} onClick={() => this.onLogoutHandler()}>
                  Logout
                </Link> */}
              </form>
            </nav>
            <Switch>
              <Route exact path="/register" component={Register} />
              <Route exact path="/login" component={Login} />
              <Route exact path="/createQuiz" component={CreateQuiz} />
              <Route exact path="/createQuestion" component={CreateQuestion} />
              <Route exact path="/listQuizzes" component={ListQuizzes} />
              <Route exact path="/attemptQuiz/:name" component={AttemptQuiz} />
            </Switch>
          </div>
        </Router>
      </div>
    );
  }
}

export default App;
